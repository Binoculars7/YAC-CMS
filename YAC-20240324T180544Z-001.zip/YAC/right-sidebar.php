<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Left Sidebar - Landed by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1 id="logo"><a href="index.html">MFM YAC</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.html">Home</a></li>
							<li>
								<a href="#">Church Layouts</a>
								<ul>
									<li><a href="left-sidebar.php">Donations</a></li>
									<li><a href="right-sidebar.php">Attendance</a></li>
									<li><a href="Members.html">Members</a></li>
									
									</li>
								</ul>
							</li>
							<li><a href="elements.html">Elements</a></li>
							<li><a href="login/index.html" class="button primary">Admin Login</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
							<h2 style="margin-bottom: -0.3em;">Church Attendance</h2>
						</header>
						<div class="row gtr-150">
							<div class="col-4 col-12-medium">

								<!-- Sidebar -->
									<section id="sidebar">
										<section>
											<h3>Add Info</h3>
											<p>

												<section>
								
								<form method="post" action="#">
									<div class="row gtr-uniform gtr-50">
										<div class="col-6 col-12-xsmall">
											<input type="text" name="dt" id="dt" required placeholder="Date" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="st" id="st" required placeholder="Service Day" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="male" id="male" required placeholder="Male" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="fmale" id="fmale" required placeholder="Female" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="newbies" id="newbies" required placeholder="No of Newbies" />
										</div>
										<div class="col-12">
											<ul class="actions">
												<li><input name="submit" type="submit" value="Add Info" class="primary" /></li>
												<li><input type="reset" value="Reset" /></li>
											</ul>
										</div>
									</div>


							<?php 


											

								if (isset($_POST['submit'])) {


											$dt = $_POST['dt'];
											$st = $_POST['st'];
											$male = $_POST['male'];
											$fmale = $_POST['fmale'];
											$newbies = $_POST['newbies'];
											$total = $male + $fmale;


								// Create connection
								$conn = mysqli_connect('localhost', 'root', '', 'amount');
								// Check connection
								if (!$conn) {
								  die("Connection failed: " . mysqli_connect_error());
								}

								$sql = "INSERT INTO donations (dt, st, male, fmale, newbies, total) VALUES ('$dt', '$st', '$male', '$fmale', '$newbies', '$total')";


								if (mysqli_query($conn, $sql)) {
								  echo "<br> <nav style='color:orange;'>New record created successfully !!!</nav>";
								} else {
								  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
								}

								mysqli_close($conn);

								}




									 ?>





								</form>
							</section>
											</p>
						
										<hr />
										
							</div>
							<div class="col-8 col-12-medium imp-medium">

								<!-- Content -->
									<section id="content">
										
										<section>
								<h3>Review</h3>
								<h4>Offering</h4>
								<div class="table-wrapper">
									<table class="alt">
										<thead>
											<tr>
												<th>Date</th>
												<th>Day</th>
												<th>Male</th>
												<th>Female</th>
												<th>Newbies</th>
												<th>Total</th>
											</tr>
										</thead>
										<tbody>
												<?php



										$conn = mysqli_connect('localhost', 'root', '', 'amount');

										
										$sqls = "SELECT `id`, `dt`, `st`, `male`, `fmale`, `newbies`, `total` FROM `donations`";

										$result = mysqli_query($conn, $sqls);
									

										while ($row = mysqli_fetch_assoc($result)) {
										    echo '<tr>';
											echo '<td>'.$row['dt'].'</td>';
											echo '<td>'.$row['st'].'</td>';
											echo '<td>'.$row['male'].'</td>';
											echo '<td>'.$row['fmale'].'</td>';
											echo '<td>'.$row['newbies'].'</td>';
											echo '<td>'.$row['total'].'</td>';
											echo '</tr>';
										}
								        mysqli_close($conn);




											 ?>

										</tbody>
										
									</table>


							


								</div>
							</section>
									
									</section>

							</div>
						</div>
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon brands alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon brands alt fa-facebook-f"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon brands alt fa-linkedin-in"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon brands alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon brands alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon solid alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>