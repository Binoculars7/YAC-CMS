<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>MFM Young Adult Church</title>
		<meta charset="utf-8" />
		<meta name="description" content="MFM Young Adult Church SW8 region | MFM YAC">
        <meta name="keywords" content="MFM, YAC">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1 id="logo"><a href="index.html">MFM YAC</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.html">Home</a></li>
							<li>
								<a href="#">Church Layouts</a>
								<ul>
									<li><a href="left-sidebar.php">Donations</a></li>
									<li><a href="right-sidebar.php">Attendance</a></li>
									<li><a href="members.html">Members</a></li>
								</ul>
							</li>
							<li><a href="elements.html">Sermon Review</a></li>
							<li><a href="login/index.html" class="button primary">Admin Login</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
							<h2 style="margin-bottom: -0.3em;">Church Members</h2>
						</header>
						<div class="row gtr-150">
							<div class="col-4 col-12-medium">

								<!-- Sidebar -->
									<section id="sidebar">
										<section>
											<h3>Add a Member</h3>
											<p>

												<section>
								
								<form method="post" action="members.php" enctype="multipart/form-data">
									<div class="row gtr-uniform gtr-50">
										<div class="col-6 col-12-xsmall">
											<input type="text" name="surname" id="surname" value="" placeholder="Surname" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="firstname" id="firstname" value="" placeholder="firstname" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="phone" id="Phone" value="" placeholder="Phone Number" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="dob" id="dob" value="" placeholder="Date of Birth" />
										</div>
										<div class="col-6 col-12-xsmall">
											<input type="text" name="email" id="email" value="" placeholder="Email" />
										</div>
										<div class="col-12">
											<select name="gender" id="gender">
												<option value="">- Gender -</option>
												<option value="Male">Male</option>
												<option value="Female">Female</option>
											</select>
										</div>
										<div class="col-12">
											<input type="file" name="myfile" multiple>
										</div>
										<div class="col-12">
											<ul class="actions">
												<li><input type="submit" name="submit" value="Add a member" class="primary" /></li>
												<li><input type="reset" value="Reset" /></li>
											</ul>
										</div>
									</div>




									<?php 

									if (isset($_POST['submit'])) {
										
										$surname = $_POST['surname'];
										$firstname = $_POST['firstname'];
										$phone = $_POST['phone'];
										$dob = $_POST['dob'];
										$email = $_POST['email'];
										$gender = $_POST['gender'];

										$filePath = "uploads/";

										$myfile = $_FILES['myfile']['name'];

										$filenamepath = $filePath . $myfile;

										$myfile_tmp = $_FILES['myfile']['tmp_name'];


										move_uploaded_file($myfile_tmp, $filenamepath);



										// Create connection
											$conn = mysqli_connect('localhost', 'root', '', 'amount');
											// Check connection
											if (!$conn) {
											  die("Connection failed: " . mysqli_connect_error());
											}

											$sql = "INSERT INTO members (surname, firstname, phone, dob, email, gender, myfile) VALUES ('$surname', '$firstname', '$phone', '$dob', '$email', '$gender', '$myfile')";


											if (mysqli_query($conn, $sql)) {
											  echo "<br> <nav style='color:orange;'>New record created successfully !!!</nav>";
											} else {	 	 
											  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
											}

											mysqli_close($conn);

										

									}


									?>




								</form>
							</section>

											</p>
										
										</section>
										<hr />
										
							</div>
							<div class="col-8 col-12-medium imp-medium">

								<!-- Content -->
									<section id="content">
										
										<section>
								<h3>Profile</h3>
								<div class="table-wrapper">
									




						
    <link rel="stylesheet" href="profile/styles.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
  <body>
    <div class="slider owl-carousel">
      <div class="card">
        <div class="img"><img src="profile/profile-1.jpeg" alt=""></div>
        <div class="content">
          
          <div class="sub-title" style="font:16px arial; font-weight: bold;">Olawale</div>
          <div class="sub-title" style="font:16px arial; font-weight: bold;">James</div>
          <p style="color: black; margin-bottom: -0.3em; font-weight: bold; font:14px arial;">23-02-2000</p>
          <p style="color: black; font-weight: bold; font:14px arial; margin-bottom: 0em;">08067890453</p>
          
        </div>
      </div>
      <div class="card">
        <div class="img"><img src="profile/profile-2.jpeg" alt=""></div>
        <div class="content">
          <div class="sub-title" style="font:16px arial; font-weight: bold;">Olawale</div>
          <div class="sub-title" style="font:16px arial; font-weight: bold;">James</div>
          <p style="color: black; margin-bottom: -0.3em; font-weight: bold; font:14px arial;">23-02-2000</p>
          <p style="color: black; font-weight: bold; font:14px arial; margin-bottom: 0em;">08067890453</p>
          
        </div>
      </div>
      <div class="card">
        <div class="img"><img src="profile/profile-3.jpeg" alt=""></div>
        <div class="content">
         <div class="sub-title" style="font:16px arial; font-weight: bold;">Olawale</div>
          <div class="sub-title" style="font:16px arial; font-weight: bold;">James</div>
          <p style="color: black; margin-bottom: -0.3em; font-weight: bold; font:14px arial;">23-02-2000</p>
          <p style="color: black; font-weight: bold; font:14px arial; margin-bottom: 0em;">08067890453</p>
          
        </div>
      </div>

      <div class="card">
        <div class="img"><img src="profile/profile-3.jpeg" alt=""></div>
        <div class="content">
         <div class="sub-title" style="font:16px arial; font-weight: bold;">Olawale</div>
          <div class="sub-title" style="font:16px arial; font-weight: bold;">James</div>
          <p style="color: black; margin-bottom: -0.3em; font-weight: bold; font:14px arial;">23-02-2000</p>
          <p style="color: black; font-weight: bold; font:14px arial; margin-bottom: 0em;">08067890453</p>
          
        </div>
      </div>


    </div>




<!-- Content -->
									<section id="content">
										
										<section><br>
								<h3>Members list</h3>
								<div class="table-wrapper">
									<table class="alt">
										<thead>
											<tr>
												<th>Name</th>
												<th>Gender</th>
												<th>Phone No</th>
												<th>Date of Birth</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>Item 1</td>
												<td>Item 1</td>
												<td>Item 1</td>
												<td>Item 1</td>
											</tr>
											<tr>
												<td>Item 2</td>
												<td>Item 1</td>
												<td>Item 1</td>
												<td>Item 1</td>
											</tr>
											<tr>
												<td>Item 3</td>
												<td>Item 1</td>
												<td>Item 1</td>
												<td>Item 1</td>
											</tr>
											<tr>
												<td>Item 4</td>
												<td>Item 1</td>
												<td>Item 1</td>
												<td>Item 1</td>
											</tr>
											<tr>
												<td>Item 5</td>
												<td>Item 1</td>
												<td>Item 1</td>
												<td>Item 1</td>
											</tr>
										</tbody>
										
									</table>
								</div>
							</section>
									
									</section>



			<?php 
            

		$conn = mysqli_connect('localhost', 'id18777373_roots', 'FNrIXctSI1BL#+j<', 'id18777373_mfmyac');

		$sqls = "SELECT `id`, `surname`, `firstname`, `phone`, `dob`, `email`, `gender`, `myfile` FROM `members`";

		$result = mysqli_query($conn, $sqls);
	

		while ($row = mysqli_fetch_assoc($result)) {
		    

			echo "

			<div class='card'>
        <div class='img'><img src='uploads/".$myfile."' alt=''></div>
        <div class='content'>
          
          <div class='sub-title' style='font:16px arial; font-weight: bold;'>".$row['surname']."</div>
          <div class='sub-title' style='font:16px arial; font-weight: bold;'>".$row['firstname']."</div>
          <p style='color: black; margin-bottom: -0.3em; font-weight: bold; font:14px arial;'>".$row['dob']."</p>
          <p style='color: black; font-weight: bold; font:14px arial; margin-bottom: 0em;'>".$row['phone']."</p>
          
        </div>
      </div>


			";

		}
        mysqli_close($conn);
        
        ?>




		























    <script>
      $(".slider").owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 2000, //2000ms = 2s;
        autoplayHoverPause: true,
      });
    </script>

  </body>
</html>




								</div>
							</section>
									
									</section>

							</div>
						</div>
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon brands alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon brands alt fa-facebook-f"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon brands alt fa-linkedin-in"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon brands alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon brands alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon solid alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; MFM YAC. All rights reserved.</li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>