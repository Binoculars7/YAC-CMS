<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form with Shake Effect | CodingNepal</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
  <div class="wrapper">
    <header style="font:24px tahoma black; margin-bottom: -0.5em;">Admin Login</header>
    <form method="">
      <div class="field email">
        <div class="input-area">
          <input name="email" type="text" placeholder="Email Address">
          <i class="icon fas fa-envelope"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div>
        <div class="error error-txt">Email can't be blank</div>
      </div>
      <div class="field password">
        <div class="input-area">
          <input name="pass" type="password" placeholder="Password">
          <i class="icon fas fa-lock"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div>
        <div class="error error-txt">Password can't be blank</div>
      </div>
      <div class="pass-txt"><a href="changepass.html">Change password?</a></div>
      <input type="submit" name="submit" value="submit" style="background:#e44c65;">



<?php 


$confirm1 = rand(10000, 99999);

#$confirm3 = uniqid();

echo $confirm1;

$to = 'ajibadepeter@gmail.com';

$subject = 'MFM Young Adult Church SW8';

$message = 'We are reminding you concerning our event. Do well to attend';

mail($to, $subject, $message);


?>


    </form>
<div class="pass-txt"><a href="../../../YAC/index.html">Home</a></div>
  <script src="script.js"></script>

</body>
</html>

Generate the number of a given alphabet 
Multiple solution to the problem given
Evaluate the value to the variable
Get all info from the user and input to the value
Protect the password of the user by adding to a hash key 

<?php

#only for me


$only = 'you are welcome';

$error = 'password failed!!!';





?>



